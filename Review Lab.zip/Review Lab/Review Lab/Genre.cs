﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Review_Lab
{
    public enum Genre
    {
        Action,
        Simulator,
        RolePlay,
        Sports,
        Shooter,
        Fighting,
        Misc,
        Racing,
        Strategy,
        Platform
    }
}
