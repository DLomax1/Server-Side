﻿
using System.Data;

namespace Review_Lab
{
    
    public class Program
    {
    


        //Chosen Publisher Ubisoft 

        public static void Main(string[] args)
        {
            string filePath = "Downloads/videogames.csv";


            Console.WriteLine();
        }

        public void Readin(string filePath)
        {
            List<VideoGame> ReadGames = new List<VideoGame>();
            VideoGame NewGame = new VideoGame();
            using (StreamReader sr = new StreamReader(filePath))
            {
                foreach (var Line in File.ReadAllLines(filePath))
                {
                   string [] GameList = sr.ReadLine().Split(',');
                    GameList[0] = Line.Name;
                    GameList[1] = Line.publisher;

                    NewGame = Line;
                    ReadGames.Add(NewGame);
                }
               
            }
          
        }
    }
}