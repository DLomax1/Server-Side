﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Review_Lab
{
    public class VideoGame : IComparable
    {
       public string Name;
        public string Platform;
        public string year;
        public Enum genre;
        public string publisher;
        public  double NaSales;
        public double EuSales;
        public double JpSales;
        public double OtherSales;
        public double GlobalSales;
        public VideoGame videoGame;

       public VideoGame(string name, string platform, string year, Enum genre, string publisher, double naSales, double euSales, double jpSales, double otherSales, double globalSales)
        {
            Name = name;
            Platform = platform;
            this.year = year;
            this.genre = genre;
            this.publisher = publisher;
            NaSales = naSales;
            EuSales = euSales;
            JpSales = jpSales;
            OtherSales = otherSales;
            GlobalSales = globalSales;
        }

       public VideoGame()
        {
            Name = string.Empty;
            Platform = string.Empty;
            year= string.Empty;
            genre = Genre.Strategy;
            publisher = string.Empty;
            NaSales = 0.0;
            EuSales = 0.0;
            JpSales = 0.0;
            OtherSales = 0.0;
            GlobalSales = 0.0;

        }

       public VideoGame(VideoGame existingVideoGame)
        {

            existingVideoGame.Name = Name;
            existingVideoGame.Platform = Platform;
            existingVideoGame.year = year;
            existingVideoGame.genre = genre;
            existingVideoGame.publisher = publisher;
            existingVideoGame.NaSales = NaSales;
            existingVideoGame.EuSales = EuSales;
            existingVideoGame.JpSales = JpSales;
            existingVideoGame.OtherSales = OtherSales;
            existingVideoGame.GlobalSales = GlobalSales;
        }

        public override string ToString()
        {
            string VideoGameString = string.Empty;

            VideoGameString += $"Name: {Name}\n";
            VideoGameString += $"Platform: {Platform}\n";
            VideoGameString += $"Year: {year}\n";
            VideoGameString += $"Genre: {genre}\n";
            VideoGameString += $"Publisher: {publisher}\n";
            VideoGameString += $"Na-Sales: {NaSales}\n";
            VideoGameString += $"Eu-Sales: {EuSales}\n";
            VideoGameString += $"Jp-Sales: {JpSales}\n";
            VideoGameString += $"Other Sales: {OtherSales}\n";
            VideoGameString += $"Global Sales: {GlobalSales}\n";

            return VideoGameString;
        }

        public int IComparable.CompareTo(object? obj)
        {
            if (obj == null) return 1;
            VideoGame videoGame = obj as VideoGame;
            if (videoGame.Name.Length == 0)
                return this.videoGame.Name.CompareTo(videoGame.Name);
            else
                throw new ArgumentException("No Name found");
        }

    }
}
